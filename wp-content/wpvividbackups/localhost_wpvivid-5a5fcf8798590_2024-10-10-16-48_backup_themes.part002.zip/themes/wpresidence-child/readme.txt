Theme Name: WpResidence
Theme URI: http://themeforest.net/user/wpestate
Description:WP Residence is a premium & responsive WordPress theme designed for Real Estate companies and independent agents.
Version: 3.3.2
Author: wpestate
Author URI: 
Text Domain: wpresidence
Tags: white, one-column, two-columns,left-sidebar, right-sidebar, fluid-layout , custom-menu, theme-options, translation-ready
License: 
License URI:

For help files go here http://help.wpresidence.net/