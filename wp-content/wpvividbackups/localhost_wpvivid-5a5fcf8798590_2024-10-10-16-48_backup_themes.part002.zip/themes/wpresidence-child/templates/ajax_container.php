<?php $show_compare=1;?>
<span class="entry-title listing_loader_title"><?php esc_html_e('Your search results','wpresidence');?></span>
<div class="spinner" id="listing_loader">
  <div class="rect1"></div>
  <div class="rect2"></div>
  <div class="rect3"></div>
  <div class="rect4"></div>
  <div class="rect5"></div>
</div>
<div id="listing_ajax_container">
</div>