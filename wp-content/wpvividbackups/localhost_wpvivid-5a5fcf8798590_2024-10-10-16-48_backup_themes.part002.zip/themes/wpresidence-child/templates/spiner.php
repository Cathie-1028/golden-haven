<div class="spinner" id="listing_loader">
  <div class="new_prelader"></div>
</div>