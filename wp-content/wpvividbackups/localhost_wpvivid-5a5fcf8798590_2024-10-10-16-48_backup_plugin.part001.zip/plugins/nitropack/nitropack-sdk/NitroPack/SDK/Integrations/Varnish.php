<?php
namespace NitroPack\SDK\Integrations;

class Varnish extends ReverseProxy {}
