=== Countdown Timer Ultimate ===
Contributors: wponlinesupport, anoopranawat, pratik-jain, piyushpatel123, patelketan
Tags: countdown timer, timer, timer countdown, countdown, event countdown timer, animated countdown timer, birthday countdown, clock, count down, countdown, countdown clock, countdown form, countdown generator, countdown system, countdown timer, countdown timer, date countdown, event countdown, flash countdown, html5 countdown, jQuery countdown, time counter, website countdown, wp countdown, wp countdown timer
Requires at least: 5.2
Tested up to: 6.4.1
Stable tag: 2.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A quick, easy way to add and display responsive Countdown timer on your website. Also work with Gutenberg shortcode block.

== Description ==
It is proven that **Countdown Timer** can increase the **conversion up to 400%** & **business revenue up to 9%**. (note- based on facts and stats.)

== ✅ Then what’s stopping you from benefiting your business?== 

✅ **Checkout demo for better understanding**

[FREE DEMO](https://demo.essentialplugin.com/countdown-timer-ultimate-demo/?utm_source=WP&utm_medium=Countdown-Timer&utm_campaign=Read-Me) | [PRO DEMO](https://demo.essentialplugin.com/prodemo/countdown-timer-ultimate-pro/?utm_source=WP&utm_medium=Countdown-Timer&utm_campaign=Read-Me)

**Download Now** the countdown timer ultimate now and enjoy the benefits.

You have to make customers believe that you are running out of stock/ products or services and that they are running out of time. There we use the **countdown timer ultimate** to make your product more desirable among your customers.

**Download Now** Countdown Timer Ultimate this tool can be used to create scarcity and urgency of your product. To create and represent this in order to convey that you have limited offers and deals and your customer has to grab them as fast as possible, you put a **Countdown Timer** on your website/ landing page.

On the back end, **Countdown Timer Ultimate**  offers a complete WordPress countdown timer management system with the ability to:

* Create unlimited timer
* Expiry Date & Time
* Timer Label
* Timer content and designing

== ✅ It Benefits in: ==

* Driving more clicks
* Boosting the sales
* Making customer take fast & positive decision
* Generating high revenue
* Scheduling the time

**Download Now** Countdown Timer Ultimate  which is the easier and the simpler way to attract more customers and persuade them to make a quick positive response about your product.

We got your back here! We serve both free and pro **Countdown Timer Ultimate** which you can easily install and use for your business.

== ✅ Overview ==

A very simple plugin to add countdown timer to your website. Countdown timer allow you to create nice and functional Countdown timer just in a few minutes. This is the best way to create beautiful Countdown for your users. You can use our Countdown timer in your posts/pages.

Also work with Gutenberg shortcode block.

You can create multiplate countdown timer and display them with shortcode. The easiest way to place your full customizable HTML5 Countdown Timer.

= ✅ Complete shortcode with all parameters: =
<code>[wpcdt-countdown id="1"]</code>

* **ID:** [wpcdt-countdown id="1"] (timer id for which you want to display timer. This parameter is required.)

= ✅ Template code is =
<code><?php echo do_shortcode('[wpcdt-countdown id="1"]'); ?></code>

You must be thinking, why us?
= Checkout these features to know your answer- =
* Fully Responsive WordPress Countdown timer.
* Ability to create unlimited Countdowns timer.
* Ability to create Countdown in pages/posts.
* Also work with Gutenberg shortcode block.
* Ability to change background color and width.
* Ability to change rotating circle background color and width.
* Option change the text of Days, hours, minutes and seconds OR show/hide Days, hours, minutes and seconds.
* Option to set difftent background colors for Days, hours, minutes and seconds.
* Elementor, Bevear and SiteOrigin, Divi, Fusion Page Builder Native Support.

Then why wait to put a **Countdown Timer Ultimate** on your website to generate high sales and revenue.

And your time starts now… **Download Now**.


= PRO Features Include =
> * 12+ stunning cool designs for clock and timer.
> * Fully customized clock.
> * Custom css
> * Fully Responsive WordPress Countdown timer.
> * Ability to create unlimited Countdowns timer.
> * Ability to create Countdown in pages/posts.
> * Template code.
> * Schedule Timer
> * Recurring Timer
> * Timer works perfectly when any cache plugin is active.
> * Ability to change background color and width.
> * Ability to change rotating circle background color and width.
> * Option to show/hide Days, hours, minutes and seconds.
> * Option to set difftent background colors for Days, hours, minutes and seconds.
> * Easy to integrate with e-commerce coupons like WooCommerce and Easy Digital Downloads.
> * Gutenberg Block Supports.
> * WPBakery Page Builder Support
> * Elementor, Beaver and SiteOrigin Page Builder Support (New).
> * Divi Page Builder Native Support (New).
> * Various parameters for clock like background color, text color and etc.
> * Clock expiration event. Display your desired text on complition of timer.
> * Light weight and fast.
> * Fully responsive
> * 100% Multi language
>

✅ **Checkout demo for better understanding**

[FREE DEMO](https://demo.essentialplugin.com/countdown-timer-ultimate-demo/?utm_source=WP&utm_medium=Countdown-Timer&utm_campaign=Read-Me) | [PRO DEMO](https://demo.essentialplugin.com/prodemo/countdown-timer-ultimate-pro/?utm_source=WP&utm_medium=Countdown-Timer&utm_campaign=Read-Me)

✅ **Essential Plugin Bundle Deal**

[Annual or Lifetime Bundle Deal](https://www.essentialplugin.com/pricing/?utm_source=WP&utm_medium=Countdown-Timer&utm_campaign=Read-Me)

= Privacy & Policy =
* We have also opt-in e-mail selection , once you download the plugin , so that we can inform you and nurture you about products and its features.

== Installation ==

1. Upload the 'Countdown Timer Ultimate' folder to the '/wp-content/plugins/' directory.
2. Activate the "Countdown Timer Ultimate" list plugin through the 'Plugins' menu in WordPress.
3. Add a new page and add desired short code in that.

== Screenshots ==

1. Front end display
2. Front end display
3. Setting
4. Also work with Gutenberg shortcode block.

== Changelog ==

= 2.6 (27, Nov 2023) =
* [*] Updated analytics SDK.
* [*] Check compatibility with WordPress version 6.4.1

= 2.5 (18, Aug 2023) =
* [*] Tested up to: 6.3
* [*] Tested with leading pagebuilder and themes.

= 2.4.1 (7, Aug 2023) =
* [*] Fixed popup content issues.
* [*] Tested up to: 6.2.2

= 2.4 (16, May 2023) =
* [*] Tested up to: 6.2

= 2.3.1 (09, March 2023) =
* [*] Fixed - Fixed some issues like design, UI of admin side, optin screen.

= 2.3 (06, March 2023) =
* [*] Fixed - Fixed one undefined PHP variable warning.
* [*] Update - Improve escaping functions for better security.

= 2.2 (24, Feb 2023) =
* [*] Fixed - Fixed one undefined PHP variable warning.
* [*] Update - Improve escaping functions for better security.

= 2.1 (09, Dec 2022) =
* [*] Tested up to: 6.1.1

= 2.0.9 (03, Nov 2022) =
* [*] Tested up to: 6.1

= 2.0.8 (17, May 2022) =
* [*] Tested up to: 6.0

= 2.0.7 (29, March 2022) =
* [+] Tested up to: 5.9.2

= 2.0.6 (08, March 2022) =
* [*] Tested up to: 5.9.1
* [-] Removed some unwanted code and files.

= 2.0.5 (11, Feb 2022) =
* [-] Removed some unwanted code and files.

= 2.0.4 (03, Feb 2022) =
* [*] Tested up to: 5.9

= 2.0.3.1 (15, Dec 2021) =
* [*] Minor fix.

= 2.0.3 (12, Nov 2021) =
* [*] Fix - Resolve Gutenberg WP-Editor script related issue.
* [*] Update - Add some text and links in Readme file.
* [*] Minor change in CSS.

= 2.0.2 (25, Oct 2021) =
* [*] Updated opt-in screen links.
* [*] Updated - Updated some important links.

= 2.0.1.1 (16, Sep 2021) =
* [*] Fixed some issues.
* [*] Fixed a variable name issue.

= 2.0.1 (15, Sep 2021) =
* [*] Tested up to: 5.8.1
* [*] Updated Demo Link.

= 2.0 (17, Aug 2021) =
* [*] Updated all external links
* [*] Tweak - Code optimization and performance improvements.

= 1.5 (14, May 2021) =
* [+] New - Added Elementor page builder native support.
* [+] New - Added Beaver page builder native support.
* [+] New - Added SiteOrigin page builder native support.
* [+] New - Added Divi page builder native support.
* [+] New - Added Fusion page builder native support.
* [*] Update - Minor JS and CSS file updated.
* [*] Tweak - Code optimization and performance improvements.

= 1.5.1 (31, May 2021) =
* [*] Tested up to: 5.7.2
* [*] Added - https link in our analytics code to avoid browser security warning.

= 1.4 (15, March 2021) =
* [*] Tested up to: 5.7

= 1.3 (29, Oct 2020) =
* [+] New - Click to copy the shortcode.
* [*] Update - Regular plugin maintenance. Updated readme file.
* [*] Added - Added our other Popular Plugins under Countdown Timer --> Install Popular Plugins From WPOS. This will help you to save your time during creating a website.

= 1.2.5 (14-07-2020) =
* [*] Follow WordPress Detailed Plugin Guidelines for Offload Media and Analytics Code.
* [*] Tested up to: 5.4.2

= 1.2.4 (27, 12 2019) =
* [*] Updated features list.
* [*] Resolved timer clear color option issue on update.

= 1.2.3 (13, August 2019) =
* [*] Updated demo link on website.

= 1.2.2 (09, Feb 2019) =
* [*] Minor change in Opt-in flow.

= 1.2.1 (27, Dec 2018) =
* [*] Update Opt-in flow.

= 1.2 (06, Dec 2018) =
* [*] Tested with WordPress 5.0 and Gutenberg.
* [*] Fixed some CSS issues.

= 1.1.5 (22, Aug 2018) =
* [*] Fix - Countdown goes incremental when time is finished. Now it will stop at zero.
* [*] Update - Updated plugin sanitize function for better storage.
* [*] Update - Updated plugin translation code. Now user can put plugin languages file in WordPress 'language' folder so plugin language file will not be loss while plugin update.

= 1.1.4 (11, June 2018) =
* [*] Follow some WordPress Detailed Plugin Guidelines.

= 1.1.3 (20-7-17) =
* Fixed conflict with third party js issue.

= 1.1.2 =
* [+] Added 'How it Work' page for better user interface.

= 1.1.1 =
* [+] Added change the text option for Days, hours, minutes and seconds.
* [+] Added width option for Countdown Timer 

= 1.1.0 =
* [+] Added UI slider to adjust the width.
* Made some changes on setting page.
* Fixed some bug.

= 1.0 =
* Initial release.